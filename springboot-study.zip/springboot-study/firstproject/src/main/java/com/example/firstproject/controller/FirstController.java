package com.example.firstproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller     // 브라우저에서 url요청시에 들어오게끔 해주는 어노테이션
public class FirstController {


    @GetMapping("/eng")    // 브라우저에서 "/eng"로 요청이 들어오면 아래 메소드가 실행됨
    public String niceToMeetYou(Model model) {
        model.addAttribute("username", "HongPark~ Nice to meet you"); // username이라는 키에 "홍길동"이라는 값을 담아서 뷰로 전달
        return "greetings"; // templates/greetings.mustache로 이동
    }

    @GetMapping("/kor")    // 브라우저에서 "/kor"로 요청이 들어오면 아래 메소드가 실행됨
    public String niceToMeetYou2(Model model) {
        model.addAttribute("username", "홍팍님 반값습니다.");
        return "greetings"; // templates/greetings.mustache로 이동
    }

    @GetMapping("/hi")    // 브라우저에서 "/hi"로 요청이 들어오면 아래 메소드가 실행됨
    public String niceToMeetYou3(Model model) {
        model.addAttribute("username", "홍팍");
        return "greetings"; // templates/greetings.mustache로 이동
    }

    @GetMapping("/test1")    // 브라우저에서 "/test1"로 요청이 들어오면 아래 메소드가 실행됨
    public String niceToMeetYou3() {
        return "test1"; // templates/test1.mustache로 이동
    }

    @GetMapping("/bye")
    public String seeYouNext(Model model) {
        model.addAttribute("nickname", "홍길동");
        return "goodbye";
    }
    @GetMapping("/random-quote")
    public String randomQuote(Model model){
        String[] quotes = {
                "행복은 습관이다. 그것을 몸에 지니라." +
                        "-허버드-",
                "고개 숙이지 마십시오. 세상을 똑바로 정면으로" +
                        "바라보십시오. -헬렌 켈러-",
                "고난의 시기에 동요하지 않ㄴ는 것, 이것은 진정 " +
                       "칭찬받을 만한 뛰어난 인물의 증거다. -베토벤-",
                "당신이 할 수 있다고 믿든 할 수 없다고 믿든 " +
                        "믿는 대로 될 것이다. -헨리 포드-",
                "작은 기회로부터 종종 위대한 업적이 시작된다. " +
                        "-데모스테네스-"
        };
        int randInt = (int) (Math.random() * quotes.length);
        model.addAttribute("randomQuote", quotes[randInt]);
        return "random-quote";
    }

}