//package com.example.firstproject.entity;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.Id;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.ToString;
//
//@Entity
//@AllArgsConstructor
//@NoArgsConstructor
//@ToString
//@Getter
//public class Member {
//    @Id     // 기본키(엔터티의 대표값 지정)
//    @GeneratedValue     //기본키 자동 생성 추가
//    Long id;
//    @Column
//    String email;
//    @Column
//    String password;
//}
