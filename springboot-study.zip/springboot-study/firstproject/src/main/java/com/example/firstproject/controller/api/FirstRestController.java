package com.example.firstproject.controller.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstRestController {
    @GetMapping("/helloworld")  //브라우저에서 hi로 요청 들어오면 아래 메소드 실행
    public String hello() {
        return "hello world";
    }

}
