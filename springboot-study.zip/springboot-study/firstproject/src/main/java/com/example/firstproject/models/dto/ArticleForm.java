package com.example.firstproject.models.dto;

import com.example.firstproject.models.entity.Article;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@ToString
//@NoArgsConstructor
@Getter
public class ArticleForm {
    private Long id;
    private String title;   // 제목을 받을 필드(속성)
    private String content; // 내용을 받을 필드(속성)

    public Article toEntity () {
        return new Article(id,title, content);
    }
}
