//package com.example.firstproject.controller;
//
//import com.example.firstproject.dto.MemberForm;
//import com.example.firstproject.entity.Member;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import com.example.firstproject.repository.MemberRepository;
//import java.util.List;
//import java.util.Objects;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.web.servlet.mvc.support.RedirectAttributes;
//
//@Controller
//@Slf4j
//public class MemberController {
//
//    @Autowired
//    private MemberRepository memberRepository;
//
//    @GetMapping("/members/new")
//    public String newMemberForm() {
//        return "members/new";
//    }
//    @GetMapping("/signup")
//    public String signUpPage() {
//        return "members/new";
//    }
//
//    @PostMapping("/join")
//    public String join(MemberForm memberForm) {
//        log.info(memberForm.toString());
//        Member member = memberForm.toEntity();
//        log.info(member.toString());
//        Member saved = memberRepository.save(member);
//        log.info(saved.toString());
//        return "redirect:/members/" + saved.getId();
//    }
//
//    @GetMapping("/members/{id}")
//    public String show(@PathVariable Long id, Model model) {
//        log.info("id: " + id);
//        Member memberEntity = memberRepository.findById(id).orElse(null);
//        model.addAttribute("member",memberEntity );
//        return "members/show";
//    }
//    @GetMapping("/members")
//    public String index(Model model) {
//        // 1. 모든 데이터 조회(List)
//        List<Member> memberList = (List<Member>)memberRepository.findAll();
//
//        // 2. 모델에 데이터 등록하기
//        model.addAttribute("memberList", memberList);
//
//        // 3. 뷰 페이지 변환하기
//        return "members/index";
//    }
//    @GetMapping("members/{id}/edit")
//    public String edit(@PathVariable Long id, Model model) {
//        Member memberEntity = memberRepository.findById(id).orElse(null);
//        model.addAttribute("member" , memberEntity);
//        return "members/edit";
//    }
//
//    @PostMapping("/members/update")
//    public String update(MemberForm memberForm) {
//        log.info(memberForm.toString());
//
//        Member memberEntity = memberForm.toEntity();
//        log.info(memberEntity.toString());
//
//        Member target = memberRepository.findById(memberEntity.getId()).orElse(null);
//        log.info(target.toString());
//        if (target !=null) {
//            memberRepository.save(memberEntity);
//        }
//        return "redirect:/members/" + memberEntity.getId();
//    }
//
//    @GetMapping("/members/{id}/delete")
//    public String delete(@PathVariable Long id, RedirectAttributes rttr) {
//        log.info("삭제 요청");
//
//        Member memberEntity = memberRepository.findById(id).orElse(null);
//        log.info(memberEntity.toString());
//
//        if (memberEntity != null) {
////        if (Objects.isNull(memberEntity)) {
//            memberRepository.delete(memberEntity);
//            rttr.addFlashAttribute("msg","삭제되었습니다.");
//        }
//        return "redirect:/members";
//    }
//}