package com.example.firstproject.service;


import com.example.firstproject.models.dto.ReplyDto;
import com.example.firstproject.models.entity.Article;
import com.example.firstproject.models.entity.Reply;
import com.example.firstproject.dao.repository.ArticleRepository;
import com.example.firstproject.dao.repository.ReplyRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ReplyService {

    @Autowired
    private ReplyRepository replyRepository;
    @Autowired
    private ArticleRepository articleRepository;

    public List<ReplyDto> replies(Long articleId) {


        // 3. List<ReplyDto> 결과로 반환
        return replyRepository.findByArticleId(articleId) //댓글 엔터티 목록 조회
                .stream()       // 댓글 엔터티 목록을 스트림으로 변환
                .map(reply -> ReplyDto.createReplyDto(reply))   // 엔터티를 DTO로 매핑
                .collect(Collectors.toList())// 스트림을 리스트로 변환
                ;
    }
    @Transactional
    // 2. 댓글 작성
    public ReplyDto create(Long articleId, ReplyDto replyDto) {
        // 1. 게시글 조회 및 존재 여부 확인 -> 없으면 예외 발생
        Article article = articleRepository.findById(articleId).orElseThrow(
                () -> new IllegalArgumentException("댓글 생성 실패! 대상 게시글이 없습니다.")
        );
        // 2. 댓글 엔터티 생성
        Reply reply = Reply.createReply(replyDto, article);
        // 3. 댓글 엔터티를 DB에 저장
        Reply created = replyRepository.save(reply);
        // 4. DB에 저장한 엔터티를 DTO로 변환해 반환
        return ReplyDto.createReplyDto(created);

    }
    @Transactional
    public ReplyDto update(Long id, ReplyDto replyDto) {
        // 1. 댓글 조회 및 존재 여부 확인 -> 없으면 예외 발생
        Reply target = replyRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("댓글 수정 실패! 대상 댓글이 없습니다.")
        );
        // 2. 댓글 수정
        target.patch(replyDto);

        // 3. 수정한 댓글 엔터티를 DB에 저장
        Reply updated = replyRepository.save(target);
        // 4. DB에 저장한 엔터티를 DTO로 변환해 반환
        return ReplyDto.createReplyDto(updated);

    }
    // 4. 댓글 삭제
    @Transactional
    public ReplyDto delete(Long id) {
        Reply target = replyRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("댓글 삭제 실패! 대상 댓글이 없습니다.")
        );
        return ReplyDto.createReplyDto(target);

    }
}
